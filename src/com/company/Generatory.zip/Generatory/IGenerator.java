package com.company.Generatory;

public interface IGenerator {
    double dajCislo();
}
